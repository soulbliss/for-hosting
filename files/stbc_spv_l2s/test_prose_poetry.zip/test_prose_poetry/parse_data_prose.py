from sys import argv

hash = {}
def readtags():
	for line in open('tags').readlines():
		hash[line.split()[0]] = int(line.strip().split()[1])

if __name__ == '__main__':
	c = 1
	readtags()
	if len(argv) != 3:
		print('parseDepData.py input output')
	data = open(argv[1]).readlines()
	writer = open(argv[2],'w')
	for line in data:
		if line == '\n':
			writer.write('\n')
			continue
		splits = line.strip().split('\t')
		
		#['1', 'in', '_', 'in', 'in', 'adp', '_', '43', 'vmod']
		#['1', 'na', 'iv', 'part.', '5', 'sambanxah']

		strw = "|w %s"%splits[1].replace(":","COL");
		#strp = "|p %s"%splits[3].replace(":","COL");
		
		#make it 3 for training and testing of stbc else 2 for poetry and prose
		strp = "|p %s"%splits[2].replace(":","COL");
		
		tag = splits[5]
		
		if tag not in hash:
			hash[tag] = c
			c+=1
		
		writer.write('%s %s %s:%s%s %s\n' % (int(splits[4]), hash[tag], int(splits[4]), tag, strw, strp))
		
	writer.close()

